﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace CE181985_Tran_Minh_Quan_Assignment_2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
